Used libraries:
DallasTemperature
LiquidCrystal_I2C
OneWire